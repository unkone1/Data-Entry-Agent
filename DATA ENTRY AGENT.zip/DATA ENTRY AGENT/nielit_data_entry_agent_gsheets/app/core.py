"""
core.py
=======
All the Selenium / matching / persistence logic for the NIELIT Data Entry
Agent, refactored out of the original CLI script so it has NO input()/print()
calls anywhere. Every function either returns data or reports progress
through an optional `log` callback (log: Callable[[str], None]).

The GUI (gui.py) is the only thing that talks to the user.
"""

from __future__ import annotations

import csv
import difflib
import json
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import pandas as pd
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    NoSuchElementException,
    TimeoutException,
    StaleElementReferenceException,
)

Logger = Callable[[str], None]


def _noop(_msg: str) -> None:
    pass


# ---------------------------------------------------------------------------
# Where we persist things -- a per-user app-data folder so it works no matter
# where the packaged app is installed / run from.
# ---------------------------------------------------------------------------
DATA_DIR = Path(os.environ.get("NIELIT_AGENT_DATA_DIR", Path.home() / ".nielit_data_entry_agent"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

MAPPING_FILE = DATA_DIR / "field_mapping.json"
LEARNED_FILE = DATA_DIR / "learned_field_matches.json"
LOG_FILE = DATA_DIR / "run_log.csv"

TYPE_DELAY = 0.03  # seconds between keystrokes, mimics human typing

SYNONYMS = {
    "fathername": ["father", "fathersname", "fatherfullname"],
    "mothername": ["mother", "mothersname", "motherfullname"],
    "guardianname": ["guardian", "guardiansname"],
    "candidatename": ["name", "studentname", "candidatename", "fullname"],
    "dateofbirth": ["dob", "dateofbirth", "birthdate"],
    "gender": ["gender", "sex"],
    "mobilenumber": ["mobile", "phone", "contactnumber", "mobileno"],
    "emailid": ["email", "emailid", "mailid"],
    "aadhaar": ["aadhar", "aadhaar", "uidai"],
    "category": ["category", "caste"],
    "address": ["address", "correspondenceaddress", "permanentaddress"],
    "pincode": ["pincode", "pin", "zipcode"],
    "state": ["state"],
    "district": ["district"],
    "nationality": ["nationality"],
    "religion": ["religion"],
    "maritalstatus": ["maritalstatus"],
    "qualification": ["qualification", "education", "highestqualification"],
}


def normalize(text: str) -> str:
    """Lowercase, strip everything but letters/digits, for robust matching."""
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


@dataclass
class FormField:
    element_id: str
    label: str
    tag: str
    input_type: str
    required: bool
    options: list = field(default_factory=list)
    frame_path: tuple = ()

    @property
    def display(self) -> str:
        req = " *" if self.required else ""
        return f"{self.label}{req}  [{self.tag}/{self.input_type}]"


# ---------------------------------------------------------------------------
# Field discovery
# ---------------------------------------------------------------------------
def _switch_to_active_window(driver):
    handles = driver.window_handles
    if handles and driver.current_window_handle != handles[-1]:
        driver.switch_to.window(handles[-1])
    return driver.current_window_handle


def _find_label_for(driver, el, elem_id) -> str:
    if elem_id:
        try:
            label_el = driver.find_element(By.CSS_SELECTOR, f"label[for='{elem_id}']")
            if label_el.text.strip():
                return label_el.text.strip()
        except NoSuchElementException:
            pass

    for attr in ("aria-label", "placeholder", "title"):
        val = el.get_attribute(attr)
        if val:
            return val.strip()

    try:
        js = """
        var el = arguments[0];
        var row = el.closest('tr') || el.closest('.form-group') || el.closest('div');
        if (!row) return '';
        var text = row.innerText || '';
        return text;
        """
        row_text = driver.execute_script(js, el)
        if row_text:
            first_line = row_text.strip().split("\n")[0]
            return first_line[:80]
    except Exception:
        pass

    return ""


def _scan_current_context(driver, frame_path) -> list:
    fields = []
    elements = driver.find_elements(
        By.CSS_SELECTOR,
        "input[type='text'], input[type='email'], input[type='tel'], "
        "input[type='date'], input:not([type]), select, textarea",
    )

    for el in elements:
        try:
            if not el.is_displayed() or not el.is_enabled():
                continue
            elem_id = el.get_attribute("id") or ""
            tag = el.tag_name
            input_type = el.get_attribute("type") or tag
            label_text = _find_label_for(driver, el, elem_id)
            required = bool(
                el.get_attribute("required")
                or el.get_attribute("aria-required") == "true"
                or "required" in (el.get_attribute("class") or "").lower()
                or "*" in label_text
            )
            options = []
            if tag == "select":
                options = [o.text.strip() for o in Select(el).options if o.text.strip()]

            fields.append(
                FormField(
                    element_id=elem_id,
                    label=label_text.strip() or f"(unlabeled {tag}#{elem_id})",
                    tag=tag,
                    input_type=input_type,
                    required=required,
                    options=options,
                    frame_path=frame_path,
                )
            )
        except Exception:
            continue

    return fields


def discover_fields(driver, log: Logger = _noop, max_depth: int = 3) -> list:
    """Scan the current page AND any nested iframes for visible form fields."""
    _switch_to_active_window(driver)
    driver.switch_to.default_content()

    try:
        WebDriverWait(driver, 10).until(
            lambda d: d.execute_script("return document.readyState") == "complete"
        )
    except TimeoutException:
        pass
    time.sleep(1)

    all_fields = []

    def walk(path):
        driver.switch_to.default_content()
        for idx in path:
            driver.switch_to.frame(idx)

        all_fields.extend(_scan_current_context(driver, tuple(path)))

        if len(path) < max_depth:
            try:
                frame_count = len(driver.find_elements(By.TAG_NAME, "iframe"))
            except Exception:
                frame_count = 0
            for i in range(frame_count):
                walk(path + [i])
                driver.switch_to.default_content()
                for idx in path:
                    driver.switch_to.frame(idx)

    walk([])
    driver.switch_to.default_content()

    if not all_fields:
        try:
            iframe_count = len(driver.find_elements(By.TAG_NAME, "iframe"))
        except Exception:
            iframe_count = "?"
        log(
            "No fields found anywhere on the page.\n"
            f"  current URL: {driver.current_url}\n"
            f"  page title:  {driver.title}\n"
            f"  iframe count at top level: {iframe_count}\n"
            f"  open browser tabs: {len(driver.window_handles)}\n"
            "  Possible causes: the form is still loading, it's inside a frame\n"
            "  deeper than 3 levels, or it uses non-standard (non input/select) markup."
        )

    return all_fields


# ---------------------------------------------------------------------------
# Column <-> field matching
# ---------------------------------------------------------------------------
def suggest_mapping(columns: list, fields: list, learned: Optional[dict] = None) -> dict:
    learned = learned or {}
    mapping = {}
    norm_fields = {f.element_id: normalize(f.label) for f in fields}

    for col in columns:
        norm_col = normalize(col)
        best_id, best_score = None, 0.0

        for fid, norm_label in norm_fields.items():
            if not norm_label:
                continue

            if norm_col == norm_label or norm_col in norm_label or norm_label in norm_col:
                score = 0.95
            else:
                score = difflib.SequenceMatcher(None, norm_col, norm_label).ratio()

            for key, syns in SYNONYMS.items():
                if norm_col in syns and key in norm_label:
                    score = max(score, 0.9)
                if norm_label in syns and key in norm_col:
                    score = max(score, 0.9)

            if learned.get(norm_col) == norm_label:
                score = max(score, 0.98)

            if score > best_score:
                best_score, best_id = score, fid

        if best_score >= 0.55:
            mapping[col] = best_id

    return mapping


def load_learned() -> dict:
    if LEARNED_FILE.exists() and LEARNED_FILE.stat().st_size > 0:
        try:
            return json.loads(LEARNED_FILE.read_text())
        except json.JSONDecodeError:
            return {}
    return {}


def save_learned(learned: dict):
    LEARNED_FILE.write_text(json.dumps(learned, indent=2))


def update_learned(learned: dict, columns: list, mapping: dict, fields_by_id: dict):
    for col in columns:
        fid = mapping.get(col)
        if fid and fid in fields_by_id:
            learned[normalize(col)] = normalize(fields_by_id[fid].label)
    save_learned(learned)


# ---------------------------------------------------------------------------
# Mapping persistence (per excel filename)
# ---------------------------------------------------------------------------
def load_all_mappings() -> dict:
    if MAPPING_FILE.exists() and MAPPING_FILE.stat().st_size > 0:
        try:
            data = json.loads(MAPPING_FILE.read_text())
            if data and all(isinstance(v, str) for v in data.values()):
                return {"_legacy": data}
            return data
        except json.JSONDecodeError:
            return {}
    return {}


def save_all_mappings(all_mappings: dict):
    MAPPING_FILE.write_text(json.dumps(all_mappings, indent=2))


# ---------------------------------------------------------------------------
# Typing values into the form
# ---------------------------------------------------------------------------
def type_into_field(driver, field_obj: FormField, value, max_retries: int = 4):
    """Types a value into a field. Raises on failure (caller collects errors)."""
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return
    value = str(value).strip()
    if not value:
        return

    last_error = None
    for _ in range(max_retries):
        try:
            driver.switch_to.default_content()
            for idx in field_obj.frame_path:
                driver.switch_to.frame(idx)

            el = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, field_obj.element_id))
            )

            if field_obj.tag == "select":
                sel = Select(el)
                try:
                    sel.select_by_visible_text(value)
                    return
                except Exception:
                    pass
                for opt in sel.options:
                    if normalize(opt.text) == normalize(value):
                        sel.select_by_visible_text(opt.text)
                        return
                for opt in sel.options:
                    if normalize(value) in normalize(opt.text):
                        sel.select_by_visible_text(opt.text)
                        return
                raise ValueError(f"could not find option '{value}' in select field '{field_obj.label}'")

            el.clear()
            for ch in value:
                el.send_keys(ch)
                time.sleep(TYPE_DELAY)

            try:
                current = el.get_attribute("value") or ""
            except StaleElementReferenceException:
                current = None
            if current is not None and normalize(current) != normalize(value):
                raise StaleElementReferenceException(
                    f"field shows {current!r} after typing, expected {value!r}"
                )
            return

        except StaleElementReferenceException as e:
            last_error = e
            time.sleep(0.4)
            continue
        except TimeoutException as e:
            last_error = e
            time.sleep(0.4)
            continue

    raise last_error or RuntimeError(f"Failed to fill '{field_obj.label}' after {max_retries} attempts")


def fill_row(driver, row, mapping: dict, fields_by_id: dict) -> list:
    """Fill one Excel row into the form. Returns a list of error strings."""
    errors = []
    for col, elem_id in mapping.items():
        f = fields_by_id.get(elem_id)
        if not f:
            continue
        try:
            type_into_field(driver, f, row.get(col))
        except Exception as e:
            errors.append(f"{col} -> {f.label}: {e}")
    return errors


def click_submit(driver, submit_button_id: str, timeout: int = 10):
    WebDriverWait(driver, timeout).until(
        EC.element_to_be_clickable((By.ID, submit_button_id))
    ).click()


# ---------------------------------------------------------------------------
# Run log (CSV) -- lets a run be safely resumed
# ---------------------------------------------------------------------------
def load_done_rows(excel_key: str) -> set:
    done = set()
    if LOG_FILE.exists():
        with open(LOG_FILE) as fh:
            for r in csv.DictReader(fh):
                if r.get("excel_file") == excel_key and r.get("status") == "done":
                    done.add(int(r["row_index"]))
    return done


def append_log_row(excel_key: str, row_index: int, status: str, detail: str):
    is_new = not LOG_FILE.exists() or LOG_FILE.stat().st_size == 0
    with open(LOG_FILE, "a", newline="") as fh:
        w = csv.writer(fh)
        if is_new:
            w.writerow(["excel_file", "row_index", "status", "detail"])
        w.writerow([excel_key, row_index, status, detail])


def remove_last_log_entry(excel_key: str, row_index: int):
    if not LOG_FILE.exists():
        return
    with open(LOG_FILE, newline="") as fh:
        rows = list(csv.reader(fh))
    if not rows:
        return
    header, body = rows[0], rows[1:]
    for i in range(len(body) - 1, -1, -1):
        r = body[i]
        if len(r) >= 2 and r[0] == excel_key and r[1] == str(row_index):
            del body[i]
            break
    with open(LOG_FILE, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(body)


# ---------------------------------------------------------------------------
# Excel loading
# ---------------------------------------------------------------------------
def load_excel(path: str, sheet) -> pd.DataFrame:
    df = pd.read_excel(path, sheet_name=sheet, dtype=str)
    df = df.where(pd.notnull(df), None)
    return df


def list_sheets(path: str) -> list:
    xl = pd.ExcelFile(path)
    return xl.sheet_names


# ---------------------------------------------------------------------------
# Google Sheets live loading
# ---------------------------------------------------------------------------
import urllib.parse


def parse_google_sheet_url(url: str) -> dict:
    """
    Parse any Google Sheets URL and return a dict with keys:
      url_type : "published" | "normal"
      sheet_id : the spreadsheet ID (long alphanumeric)
      pub_id   : the published e/... ID (only for published URLs)
      gid      : tab gid string (default "0")
      raw_url  : original URL (used as-is for direct published CSV links)

    Handles all three URL formats:
      Normal share URL:
        https://docs.google.com/spreadsheets/d/<ID>/edit#gid=<GID>
      Publish-to-web URL (with /e/ path):
        https://docs.google.com/spreadsheets/d/e/2PACX-<PUBID>/pub?gid=<GID>&output=csv
      Publish-to-web URL (direct CSV link already):
        same as above but already ends in output=csv
    """
    url = url.strip()

    # Extract gid from anywhere in the URL
    gid_match = re.search(r"[#&?]gid=(\d+)", url)
    gid = gid_match.group(1) if gid_match else "0"

    # Case 1: Published URL — contains /d/e/ in path
    # e.g. https://docs.google.com/spreadsheets/d/e/2PACX-1vXXXX.../pub?...
    pub_match = re.search(r"/spreadsheets/d/e/([^/?#]+)", url)
    if pub_match:
        pub_id = pub_match.group(1)
        return {
            "url_type": "published",
            "sheet_id": None,
            "pub_id": pub_id,
            "gid": gid,
            "raw_url": url,
        }

    # Case 2: Normal sheet URL — contains /d/<ID>/ (ID is long alphanumeric, not just "e")
    normal_match = re.search(r"/spreadsheets/d/([A-Za-z0-9_-]{10,})", url)
    if normal_match:
        sheet_id = normal_match.group(1)
        return {
            "url_type": "normal",
            "sheet_id": sheet_id,
            "pub_id": None,
            "gid": gid,
            "raw_url": url,
        }

    raise ValueError(
        "Could not recognise this Google Sheets URL.\n\n"
        "Please paste one of these:\n"
        "  • The normal share URL  (File → Share → Copy link)\n"
        "  • The published CSV URL  (File → Share → Publish to web → Copy link)"
    )


def google_sheet_csv_urls(parsed: dict) -> list:
    """
    Build the list of CSV URLs to try, given the parsed URL dict.

    For published URLs: the /pub URL is used directly (most reliable).
    For normal URLs: try /pub with the sheet_id, then /export.
    """
    gid = parsed["gid"]

    if parsed["url_type"] == "published":
        pub_id = parsed["pub_id"]
        base = f"https://docs.google.com/spreadsheets/d/e/{pub_id}/pub"
        urls = []
        # Try without gid first (most reliable for published sheets)
        urls.append(f"{base}?output=csv")
        # Then with gid (needed when sheet has multiple tabs)
        if gid != "0":
            urls.append(f"{base}?gid={gid}&single=true&output=csv")
        else:
            urls.append(f"{base}?gid={gid}&single=true&output=csv")
        return urls

    # Normal sheet URL
    sid = parsed["sheet_id"]
    return [
        f"https://docs.google.com/spreadsheets/d/{sid}/pub?gid={gid}&single=true&output=csv",
        f"https://docs.google.com/spreadsheets/d/{sid}/export?format=csv&gid={gid}",
    ]


_SHARE_INSTRUCTIONS = (
    "To fix this, PUBLISH your sheet to the web:\n"
    "  1. Open the sheet in Google Sheets\n"
    "  2. Click  File  =>  Share  =>  Publish to web\n"
    "  3. Choose the correct tab, set format to CSV\n"
    "  4. Click Publish and confirm\n"
    "  5. Then paste the normal sheet URL here again.\n\n"
    "Note: File => Share => Share with others (Anyone with link) alone is NOT\n"
    "enough for headless CSV access — you must also Publish to web."
)


def load_google_sheet(url: str, log: Logger = _noop) -> pd.DataFrame:
    """
    Fetch a Google Sheet as a DataFrame.
    Tries /pub (Published to web) first, then /export as fallback.
    Raises ValueError with actionable instructions on failure.
    """
    import io
    try:
        import requests
    except ImportError:
        raise ImportError(
            "The requests library is required.\n"
            "Run:  pip install requests"
        )

    parsed = parse_google_sheet_url(url)
    log(f"Loading Google Sheet  type={parsed['url_type']}  id={parsed.get('sheet_id') or parsed.get('pub_id')}  gid={parsed['gid']}")

    urls = google_sheet_csv_urls(parsed)
    last_status = None
    last_body = ""

    for csv_url in urls:
        log(f"Trying: {csv_url}")
        try:
            resp = requests.get(csv_url, timeout=30, allow_redirects=True)
        except requests.exceptions.ConnectionError as e:
            raise ValueError(
                f"Could not connect to Google Sheets.\n"
                f"Check your internet connection.\nDetail: {e}"
            ) from e
        except requests.exceptions.Timeout:
            raise ValueError("Request timed out. Check your internet connection.")

        ct = resp.headers.get("Content-Type", "")
        body = resp.text.strip()
        last_status = resp.status_code
        last_body = body[:400]

        if resp.status_code == 200 and "text/html" not in ct and body:
            log(f"Success (HTTP 200)")
            try:
                df = pd.read_csv(io.StringIO(body), dtype=str)
            except Exception as e:
                raise ValueError(
                    f"Could not parse sheet as CSV.\nReason: {e}\nPreview: {body[:200]}"
                ) from e
            if df.empty:
                raise ValueError("Sheet loaded but has no data rows.")
            df = df.where(pd.notnull(df), None)
            log(f"Loaded {len(df)} rows, {len(df.columns)} columns from Google Sheets.")
            return df

        log(f"Failed: HTTP {resp.status_code}, Content-Type: {ct}")

    raise ValueError(
        f"Could not load the sheet as CSV (last HTTP status: {last_status}).\n\n"
        + _SHARE_INSTRUCTIONS +
        f"\n\nLast response preview:\n{last_body}"
    )



def list_google_sheet_tabs(url: str, log: Logger = _noop) -> list[dict]:
    """
    Return a list of tabs in the Google Sheet as dicts with 'title' and 'gid'.
    Uses the Sheets JSON feed (no API key needed for public sheets).
    """
    try:
        import requests
    except ImportError:
        raise ImportError("The 'requests' library is required.")

    parsed = parse_google_sheet_url(url)
    sheet_id = parsed.get("sheet_id")
    if not sheet_id:
        # Published URL — we can't look up tabs via feeds API, return default
        return [{"title": "Sheet1", "gid": parsed["gid"] or "0"}]
    feed_url = f"https://spreadsheets.google.com/feeds/worksheets/{sheet_id}/public/basic?alt=json"
    log(f"Fetching sheet tab list from feeds API...")

    try:
        resp = requests.get(feed_url, timeout=15)
        if resp.status_code == 200:
            data = resp.json()
            entries = data.get("feed", {}).get("entry", [])
            tabs = []
            for entry in entries:
                title = entry.get("title", {}).get("$t", "Sheet")
                # gid is embedded in the id link
                id_str = entry.get("id", {}).get("$t", "")
                gid_match = re.search(r"/(\d+)$", id_str)
                gid = gid_match.group(1) if gid_match else "0"
                tabs.append({"title": title, "gid": gid})
            if tabs:
                return tabs
    except Exception:
        pass

    # Fallback: return a single default tab
    parsed = parse_google_sheet_url(url)
    return [{"title": "Sheet1", "gid": parsed["gid"] or "0"}]
