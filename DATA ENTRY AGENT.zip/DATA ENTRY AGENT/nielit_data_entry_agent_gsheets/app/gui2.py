"""
gui.py
======
A Tkinter desktop UI for the NIELIT Data Entry Agent.

Flow (as tabs, left to right):
  1. Browser   -- launch Chrome, let the user log in / navigate manually,
                  then scan the page for fillable fields.
  2. Excel     -- pick the spreadsheet and sheet to load.
  3. Mapping   -- review / fix which Excel column goes into which form field.
  4. Run       -- step through rows one at a time, fill, review, submit
                  yourself, redo, skip, or stop -- with full logging.

Nothing here ever pastes into the page; typing is done character-by-character
via Selenium, same as the original script. All CAPTCHA / login / final
"Submit" clicks are left to the human by default.
"""

from __future__ import annotations

import os
import queue
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from typing import Optional

from . import core

DEFAULT_START_URL = "https://student.nielit.gov.in/"


class DataEntryApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("NIELIT Data Entry Agent")
        self.geometry("980x680")
        self.minsize(860, 600)

        # ---- shared state ----
        self.driver = None
        self.fields: list[core.FormField] = []
        self.fields_by_id: dict[str, core.FormField] = {}

        self.excel_path: Optional[str] = None
        self.excel_key: Optional[str] = None
        self.df = None
        self.mapping: dict[str, str] = {}
        self.all_mappings = core.load_all_mappings()
        self.learned = core.load_learned()

        self.done_indices: set[int] = set()
        self.current_idx = 0
        self.redo_count = 0

        self.log_queue: "queue.Queue[str]" = queue.Queue()

        self._build_ui()
        self._poll_log_queue()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=8, pady=(8, 0))

        self.tab_browser = ttk.Frame(self.notebook)
        self.tab_excel = ttk.Frame(self.notebook)
        self.tab_mapping = ttk.Frame(self.notebook)
        self.tab_run = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_browser, text="1. Browser & Form")
        self.notebook.add(self.tab_excel, text="2. Excel Data")
        self.notebook.add(self.tab_mapping, text="3. Field Mapping")
        self.notebook.add(self.tab_run, text="4. Run Entry")

        self._build_browser_tab()
        self._build_excel_tab()
        self._build_mapping_tab()
        self._build_run_tab()

        # ---- shared log panel at the bottom ----
        log_frame = ttk.LabelFrame(self, text="Log")
        log_frame.pack(fill="both", expand=False, padx=8, pady=8)
        self.log_text = tk.Text(log_frame, height=8, wrap="word", state="disabled")
        self.log_text.pack(fill="both", expand=True, side="left")
        scroll = ttk.Scrollbar(log_frame, command=self.log_text.yview)
        scroll.pack(side="right", fill="y")
        self.log_text["yscrollcommand"] = scroll.set

    # -- Tab 1: Browser --------------------------------------------------
    def _build_browser_tab(self):
        f = self.tab_browser
        pad = {"padx": 8, "pady": 6}

        ttk.Label(f, text="Start URL:").grid(row=0, column=0, sticky="w", **pad)
        self.url_var = tk.StringVar(value=DEFAULT_START_URL)
        ttk.Entry(f, textvariable=self.url_var, width=60).grid(row=0, column=1, sticky="w", **pad)

        self.btn_launch = ttk.Button(f, text="Launch Chrome", command=self.on_launch_browser)
        self.btn_launch.grid(row=1, column=0, sticky="w", **pad)

        ttk.Label(
            f,
            text=(
                "After Chrome opens: log in, solve any CAPTCHA/OTP, and navigate\n"
                "to the exact data-entry form page yourself. Once the form (all\n"
                "fields) is fully visible on screen, click 'Scan Form Fields' below."
            ),
            justify="left",
        ).grid(row=2, column=0, columnspan=2, sticky="w", **pad)

        self.btn_scan = ttk.Button(
            f, text="Scan Form Fields", command=self.on_scan_fields, state="disabled"
        )
        self.btn_scan.grid(row=3, column=0, sticky="w", **pad)

        ttk.Label(f, text="Discovered fields:").grid(row=4, column=0, sticky="w", **pad)
        self.fields_list = tk.Listbox(f, height=14, width=100)
        self.fields_list.grid(row=5, column=0, columnspan=2, sticky="nsew", padx=8, pady=6)
        f.rowconfigure(5, weight=1)
        f.columnconfigure(1, weight=1)

    # -- Tab 2: Excel -----------------------------------------------------
    def _build_excel_tab(self):
        f = self.tab_excel
        pad = {"padx": 8, "pady": 6}

        ttk.Button(f, text="Choose Excel File...", command=self.on_choose_excel).grid(
            row=0, column=0, sticky="w", **pad
        )
        self.excel_path_var = tk.StringVar(value="(no file selected)")
        ttk.Label(f, textvariable=self.excel_path_var).grid(row=0, column=1, sticky="w", **pad)

        ttk.Label(f, text="Sheet:").grid(row=1, column=0, sticky="w", **pad)
        self.sheet_var = tk.StringVar()
        self.sheet_combo = ttk.Combobox(f, textvariable=self.sheet_var, state="readonly", width=30)
        self.sheet_combo.grid(row=1, column=1, sticky="w", **pad)

        self.btn_load_excel = ttk.Button(
            f, text="Load Sheet", command=self.on_load_excel_sheet, state="disabled"
        )
        self.btn_load_excel.grid(row=2, column=0, sticky="w", **pad)

        ttk.Label(f, text="Preview (first 20 rows):").grid(row=3, column=0, sticky="w", **pad)
        self.preview_tree = ttk.Treeview(f, show="headings", height=16)
        self.preview_tree.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=8, pady=6)
        f.rowconfigure(4, weight=1)
        f.columnconfigure(1, weight=1)

    # -- Tab 3: Mapping -----------------------------------------------------
    def _build_mapping_tab(self):
        f = self.tab_mapping
        pad = {"padx": 8, "pady": 6}

        top = ttk.Frame(f)
        top.pack(fill="x", **pad)
        ttk.Button(top, text="Auto-Suggest Mapping", command=self.on_autosuggest).pack(side="left")
        ttk.Button(top, text="Save Mapping", command=self.on_save_mapping).pack(side="left", padx=8)
        ttk.Label(top, text="(double-click a row to change its mapped form field)").pack(side="left", padx=8)

        columns = ("excel_col", "form_field", "required")
        self.map_tree = ttk.Treeview(f, columns=columns, show="headings", height=20)
        self.map_tree.heading("excel_col", text="Excel Column")
        self.map_tree.heading("form_field", text="Mapped Form Field")
        self.map_tree.heading("required", text="Required?")
        self.map_tree.column("excel_col", width=220)
        self.map_tree.column("form_field", width=460)
        self.map_tree.column("required", width=100, anchor="center")
        self.map_tree.pack(fill="both", expand=True, padx=8, pady=6)
        self.map_tree.bind("<Double-1>", self.on_edit_mapping_row)

        self.map_warning_var = tk.StringVar(value="")
        ttk.Label(f, textvariable=self.map_warning_var, foreground="#b00020").pack(
            fill="x", padx=8, pady=(0, 8)
        )

    # -- Tab 4: Run -----------------------------------------------------
    def _build_run_tab(self):
        f = self.tab_run
        pad = {"padx": 8, "pady": 6}

        top = ttk.Frame(f)
        top.pack(fill="x", **pad)
        self.auto_submit_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(
            top, text="Auto-click submit button after each row", variable=self.auto_submit_var
        ).pack(side="left")
        ttk.Label(top, text="Submit button element id:").pack(side="left", padx=(16, 4))
        self.submit_id_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.submit_id_var, width=25).pack(side="left")

        row2 = ttk.Frame(f)
        row2.pack(fill="x", **pad)
        ttk.Button(row2, text="Start / Resume Run", command=self.on_start_run).pack(side="left")
        ttk.Button(row2, text="Jump to row...", command=self.on_jump_to_row).pack(side="left", padx=8)

        self.progress_var = tk.StringVar(value="No run started.")
        ttk.Label(f, textvariable=self.progress_var, font=("TkDefaultFont", 11, "bold")).pack(
            anchor="w", padx=8, pady=(4, 2)
        )

        ttk.Label(f, text="Current row data:").pack(anchor="w", padx=8)
        self.row_tree = ttk.Treeview(f, columns=("col", "val"), show="headings", height=10)
        self.row_tree.heading("col", text="Column")
        self.row_tree.heading("val", text="Value")
        self.row_tree.column("col", width=220)
        self.row_tree.column("val", width=500)
        self.row_tree.pack(fill="both", expand=True, padx=8, pady=6)

        btns = ttk.Frame(f)
        btns.pack(fill="x", padx=8, pady=6)
        self.btn_fill = ttk.Button(btns, text="Fill This Row", command=self.on_fill_row, state="disabled")
        self.btn_fill.pack(side="left")
        self.btn_redo = ttk.Button(btns, text="Redo (retype row)", command=self.on_redo_row, state="disabled")
        self.btn_redo.pack(side="left", padx=6)
        self.btn_submit_click = ttk.Button(
            btns, text="Click Submit Button", command=self.on_click_submit, state="disabled"
        )
        self.btn_submit_click.pack(side="left", padx=6)
        self.btn_mark_done = ttk.Button(
            btns, text="Mark Submitted -> Next Row", command=self.on_mark_done_next, state="disabled"
        )
        self.btn_mark_done.pack(side="left", padx=6)
        self.btn_skip = ttk.Button(btns, text="Skip Row", command=self.on_skip_row, state="disabled")
        self.btn_skip.pack(side="left", padx=6)
        self.btn_redo_prev = ttk.Button(
            btns, text="Redo PREVIOUS submitted row", command=self.on_redo_previous, state="disabled"
        )
        self.btn_redo_prev.pack(side="left", padx=6)

    # ------------------------------------------------------------------
    # Logging helpers (thread-safe via queue)
    # ------------------------------------------------------------------
    def log(self, msg: str):
        self.log_queue.put(str(msg))

    def _poll_log_queue(self):
        try:
            while True:
                msg = self.log_queue.get_nowait()
                self.log_text.configure(state="normal")
                self.log_text.insert("end", msg + "\n")
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass
        self.after(150, self._poll_log_queue)

    def run_in_thread(self, target, on_done=None, on_error=None):
        """Run `target` (a zero-arg callable) in a background thread so the
        GUI doesn't freeze, then marshal the result back to the main thread."""

        def worker():
            try:
                result = target()
            except Exception as e:  # noqa: BLE001
                self.after(0, lambda: (on_error(e) if on_error else self._default_error(e)))
                return
            if on_done:
                self.after(0, lambda: on_done(result))

        threading.Thread(target=worker, daemon=True).start()

    def _default_error(self, e: Exception):
        self.log(f"ERROR: {e}")
        messagebox.showerror("Error", str(e))

    # ------------------------------------------------------------------
    # Tab 1 handlers
    # ------------------------------------------------------------------
    def on_launch_browser(self):
        self.btn_launch.configure(state="disabled")
        self.log("Launching Chrome...")

        def task():
            from selenium import webdriver

            options = webdriver.ChromeOptions()
            options.add_experimental_option("detach", True)
            chromedriver_path = os.environ.get("CHROMEDRIVER_PATH")
            if chromedriver_path:
                driver = webdriver.Chrome(
                    service=webdriver.ChromeService(chromedriver_path), options=options
                )
            else:
                driver = webdriver.Chrome(options=options)
            driver.get(self.url_var.get().strip() or DEFAULT_START_URL)
            return driver

        def done(driver):
            self.driver = driver
            self.log("Chrome opened. Log in / navigate to the form, then click 'Scan Form Fields'.")
            self.btn_scan.configure(state="normal")
            self.btn_launch.configure(state="normal")

        def err(e):
            self.btn_launch.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    def on_scan_fields(self):
        if not self.driver:
            messagebox.showwarning("No browser", "Launch Chrome first.")
            return
        self.btn_scan.configure(state="disabled")
        self.log("Scanning page for form fields...")

        def task():
            return core.discover_fields(self.driver, log=self.log)

        def done(fields):
            self.btn_scan.configure(state="normal")
            self.fields = fields
            self.fields_by_id = {f.element_id: f for f in fields}
            self.fields_list.delete(0, "end")
            for fld in fields:
                self.fields_list.insert("end", fld.display)
            self.log(f"Discovered {len(fields)} fields.")
            if not fields:
                messagebox.showwarning(
                    "No fields found",
                    "No fillable fields were found on this page. Make sure the "
                    "form is fully loaded and visible, then try again.",
                )

        def err(e):
            self.btn_scan.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    # ------------------------------------------------------------------
    # Tab 2 handlers
    # ------------------------------------------------------------------
    def on_choose_excel(self):
        path = filedialog.askopenfilename(
            title="Choose Excel file",
            filetypes=[("Excel files", "*.xlsx *.xls *.xlsm"), ("All files", "*.*")],
        )
        if not path:
            return
        self.excel_path = path
        self.excel_key = os.path.basename(path)
        self.excel_path_var.set(path)
        try:
            sheets = core.list_sheets(path)
        except Exception as e:
            self._default_error(e)
            return
        self.sheet_combo["values"] = sheets
        if sheets:
            self.sheet_var.set(sheets[0])
        self.btn_load_excel.configure(state="normal")

    def on_load_excel_sheet(self):
        if not self.excel_path:
            return
        try:
            df = core.load_excel(self.excel_path, self.sheet_var.get())
        except Exception as e:
            self._default_error(e)
            return
        self.df = df
        self.log(f"Loaded {len(df)} rows, columns: {list(df.columns)}")

        # preview
        self.preview_tree.delete(*self.preview_tree.get_children())
        cols = list(df.columns)
        self.preview_tree["columns"] = cols
        for c in cols:
            self.preview_tree.heading(c, text=c)
            self.preview_tree.column(c, width=140)
        for _, row in df.head(20).iterrows():
            self.preview_tree.insert("", "end", values=[row.get(c) for c in cols])

        # bring forward any previously-saved mapping for this file
        self.mapping = self.all_mappings.get(self.excel_key) or self.all_mappings.pop("_legacy", {}) or {}
        self._refresh_mapping_table()
        messagebox.showinfo(
            "Loaded",
            f"Loaded {len(df)} rows. Go to the 'Field Mapping' tab next "
            "(click 'Auto-Suggest Mapping' if you haven't mapped this file before).",
        )

    # ------------------------------------------------------------------
    # Tab 3 handlers
    # ------------------------------------------------------------------
    def on_autosuggest(self):
        if self.df is None:
            messagebox.showwarning("No data", "Load an Excel sheet first.")
            return
        if not self.fields:
            messagebox.showwarning("No fields", "Scan the form fields first (Tab 1).")
            return
        self.mapping = core.suggest_mapping(list(self.df.columns), self.fields, self.learned)
        self._refresh_mapping_table()
        self.log("Auto-suggested a field mapping. Please review it before running.")

    def _refresh_mapping_table(self):
        self.map_tree.delete(*self.map_tree.get_children())
        if self.df is None:
            return
        unmapped_required = []
        mapped_ids = set(self.mapping.values())
        for col in self.df.columns:
            fid = self.mapping.get(col)
            fobj = self.fields_by_id.get(fid)
            label = fobj.label if fobj else "(no match -- double-click to set)"
            req = "yes" if fobj and fobj.required else ""
            self.map_tree.insert("", "end", iid=col, values=(col, label, req))

        for fobj in self.fields:
            if fobj.required and fobj.element_id not in mapped_ids:
                unmapped_required.append(fobj.label)

        if unmapped_required:
            self.map_warning_var.set(
                "WARNING: these REQUIRED form fields have no Excel column mapped: "
                + ", ".join(unmapped_required)
            )
        else:
            self.map_warning_var.set("")

    def on_edit_mapping_row(self, _event):
        sel = self.map_tree.selection()
        if not sel:
            return
        col = sel[0]  # iid == column name
        options = ["-- none --"] + [f.display for f in self.fields]
        choice = simpledialog.askstring(
            "Choose form field",
            f"Type the number of the form field for Excel column '{col}':\n\n"
            + "\n".join(f"{i}. {o}" for i, o in enumerate(options)),
        )
        if choice is None:
            return
        choice = choice.strip()
        if not choice.isdigit() or not (0 <= int(choice) < len(options)):
            return
        idx = int(choice)
        if idx == 0:
            self.mapping.pop(col, None)
        else:
            self.mapping[col] = self.fields[idx - 1].element_id
        self._refresh_mapping_table()

    def on_save_mapping(self):
        if not self.excel_key:
            messagebox.showwarning("No file", "Load an Excel sheet first.")
            return
        self.all_mappings[self.excel_key] = self.mapping
        core.save_all_mappings(self.all_mappings)
        core.update_learned(self.learned, list(self.df.columns), self.mapping, self.fields_by_id)
        self.log(f"Mapping for '{self.excel_key}' saved (and learned for future files).")
        messagebox.showinfo("Saved", "Mapping saved. You can now go to the 'Run Entry' tab.")

    # ------------------------------------------------------------------
    # Tab 4 handlers
    # ------------------------------------------------------------------
    def on_start_run(self):
        if self.df is None or not self.mapping:
            messagebox.showwarning("Not ready", "Load Excel data and save a mapping first.")
            return
        if not self.driver or not self.fields:
            messagebox.showwarning("Not ready", "Launch the browser and scan fields first.")
            return
        self.done_indices = core.load_done_rows(self.excel_key)
        pending = [i for i in range(len(self.df)) if i not in self.done_indices]
        self.current_idx = pending[0] if pending else 0
        self.redo_count = 0
        self._show_current_row()
        for b in (self.btn_fill, self.btn_skip):
            b.configure(state="normal")
        self.log(
            f"Ready. {len(self.df)} total rows, {len(self.done_indices)} already done, "
            f"{len(pending)} pending."
        )

    def on_jump_to_row(self):
        if self.df is None:
            return
        n = simpledialog.askinteger(
            "Jump to row", f"Row number (1-{len(self.df)}):", minvalue=1, maxvalue=len(self.df)
        )
        if n:
            self.current_idx = n - 1
            self._show_current_row()

    def _show_current_row(self):
        if self.df is None or self.current_idx >= len(self.df):
            self.progress_var.set("All rows processed.")
            self.row_tree.delete(*self.row_tree.get_children())
            for b in (self.btn_fill, self.btn_redo, self.btn_submit_click, self.btn_mark_done, self.btn_skip):
                b.configure(state="disabled")
            return
        row = self.df.iloc[self.current_idx]
        label = f"Row {self.current_idx + 1} / {len(self.df)}"
        if self.redo_count:
            label += f"  (redo #{self.redo_count})"
        self.progress_var.set(label)
        self.row_tree.delete(*self.row_tree.get_children())
        for col in self.df.columns:
            self.row_tree.insert("", "end", values=(col, row.get(col)))
        self.btn_fill.configure(state="normal")
        self.btn_skip.configure(state="normal")
        self.btn_redo.configure(state="disabled")
        self.btn_mark_done.configure(state="disabled")
        self.btn_submit_click.configure(state="disabled")
        self.btn_redo_prev.configure(state="normal" if self.current_idx > 0 else "disabled")

    def on_fill_row(self):
        row = self.df.iloc[self.current_idx]
        self.btn_fill.configure(state="disabled")
        self.log(f"Filling row {self.current_idx + 1}...")

        def task():
            return core.fill_row(self.driver, row, self.mapping, self.fields_by_id)

        def done(errors):
            if errors:
                self.log("Errors while filling this row:")
                for e in errors:
                    self.log(f"   - {e}")
            else:
                self.log("Row filled. Review it in the browser, solve any CAPTCHA, then submit.")

            if self.auto_submit_var.get() and self.submit_id_var.get().strip():
                self.on_click_submit(auto_advance=True)
            else:
                self.btn_redo.configure(state="normal")
                self.btn_mark_done.configure(state="normal")
                self.btn_submit_click.configure(
                    state="normal" if self.submit_id_var.get().strip() else "disabled"
                )

        def err(e):
            self.btn_fill.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    def on_redo_row(self):
        self.redo_count += 1
        self.log("Redoing this row -- retyping all mapped fields...")
        self._show_current_row()
        self.progress_var.set(
            f"Row {self.current_idx + 1} / {len(self.df)}  (redo #{self.redo_count})"
        )
        self.on_fill_row()

    def on_click_submit(self, auto_advance=False):
        submit_id = self.submit_id_var.get().strip()
        if not submit_id:
            messagebox.showwarning("No submit id", "Enter the submit button's element id first.")
            return
        self.btn_submit_click.configure(state="disabled")

        def task():
            core.click_submit(self.driver, submit_id)

        def done(_):
            self.log("Submit button clicked.")
            if auto_advance:
                self._log_and_advance("done", "auto-submitted")
            else:
                self.btn_mark_done.configure(state="normal")

        def err(e):
            self.btn_submit_click.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    def on_mark_done_next(self):
        detail = "manually submitted"
        if self.redo_count:
            detail += f" (after {self.redo_count} redo(s))"
        self._log_and_advance("done", detail)

    def on_skip_row(self):
        self._log_and_advance("skipped", "user skipped")

    def _log_and_advance(self, status, detail):
        core.append_log_row(self.excel_key, self.current_idx, status, detail)
        self.log(f"Row {self.current_idx + 1}: {status} ({detail})")
        self.done_indices.add(self.current_idx)
        self.redo_count = 0
        self.current_idx += 1
        # skip any rows already marked done in a previous run
        while self.current_idx < len(self.df) and self.current_idx in self.done_indices:
            self.current_idx += 1
        self._show_current_row()

    def on_redo_previous(self):
        prev_idx = self.current_idx - 1
        if prev_idx < 0:
            return
        if not messagebox.askyesno(
            "Redo previous row",
            f"This will remove the log entry for row {prev_idx + 1} and let you "
            "re-fill/re-submit it (e.g. if the site rejected it). Continue?",
        ):
            return
        core.remove_last_log_entry(self.excel_key, prev_idx)
        self.done_indices.discard(prev_idx)
        self.current_idx = prev_idx
        self.redo_count = 0
        self._show_current_row()


def main():
    app = DataEntryApp()
    app.mainloop()


if __name__ == "__main__":
    main()
