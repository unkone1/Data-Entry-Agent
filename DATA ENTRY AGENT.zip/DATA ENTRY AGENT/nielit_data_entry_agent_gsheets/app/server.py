"""
server.py
=========
Local Flask backend for the NIELIT Data Entry Agent's React UI.

Runs entirely on your machine (127.0.0.1) -- the React page talks to this
server, which drives an actual Chrome window via Selenium using core.py.
No data leaves your computer except to the site you point Chrome at.
"""

from __future__ import annotations

import io
import itertools
import os
import threading
import time
import traceback
from dataclasses import asdict
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory
import pandas as pd

from . import core

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "static"
UPLOAD_DIR = BASE_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__, static_folder=str(STATIC_DIR), static_url_path="")

# ---------------------------------------------------------------------------
# Global (single-session) state -- this app is meant for one operator driving
# one browser at a time, so a module-level state dict keeps things simple.
# ---------------------------------------------------------------------------
_lock = threading.RLock()
_log_id = itertools.count(1)

state = {
    "driver": None,
    "fields": [],           # list[core.FormField]
    "fields_by_id": {},
    "excel_path": None,
    "excel_key": None,
    "df": None,
    "sheets": [],
    "mapping": {},
    "all_mappings": core.load_all_mappings(),
    "learned": core.load_learned(),
    "done_indices": set(),
    "current_idx": 0,
    "redo_count": 0,
    "logs": [],  # list of {id, ts, msg}
}


def log(msg: str):
    with _lock:
        state["logs"].append({"id": next(_log_id), "ts": time.time(), "msg": str(msg)})
        # keep log bounded
        if len(state["logs"]) > 2000:
            state["logs"] = state["logs"][-1000:]


def field_to_dict(f: core.FormField) -> dict:
    d = asdict(f)
    d["frame_path"] = list(d["frame_path"])
    return d


def error_response(e: Exception, code: int = 400):
    log(f"ERROR: {e}")
    traceback.print_exc()
    return jsonify({"ok": False, "error": str(e)}), code


# ---------------------------------------------------------------------------
# Static frontend
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    from flask import make_response
    resp = make_response(send_from_directory(STATIC_DIR, "index.html"))
    resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    resp.headers["Pragma"] = "no-cache"
    resp.headers["Expires"] = "0"
    return resp


# ---------------------------------------------------------------------------
# Browser / field discovery
# ---------------------------------------------------------------------------
@app.route("/api/launch-browser", methods=["POST"])
def launch_browser():
    data = request.get_json(force=True, silent=True) or {}
    url = (data.get("url") or "https://student.nielit.gov.in/").strip()
    try:
        with _lock:
            if state["driver"] is not None:
                return jsonify({"ok": True, "already_open": True})
            from selenium import webdriver

            options = webdriver.ChromeOptions()
            options.add_experimental_option("detach", True)
            # Fix for Selenium-launched Chrome rendering a black/blank window:
            # the automation-controlled window's GPU compositor can fail to
            # paint on many machines. These flags force software rendering
            # and a stable window size so the page actually shows up.
            options.add_argument("--disable-gpu")
            options.add_argument("--disable-software-rasterizer")
            options.add_argument("--disable-gpu-compositing")
            options.add_argument("--disable-features=UseOzonePlatform,Vulkan")
            options.add_argument("--window-size=1280,900")
            chromedriver_path = os.environ.get("CHROMEDRIVER_PATH")
            if chromedriver_path:
                driver = webdriver.Chrome(
                    service=webdriver.ChromeService(chromedriver_path), options=options
                )
            else:
                driver = webdriver.Chrome(options=options)
            driver.get(url)
            state["driver"] = driver
        log(f"Chrome launched at {url}. Log in / navigate to the form, then scan fields.")
        return jsonify({"ok": True})
    except Exception as e:
        return error_response(e)


@app.route("/api/scan-fields", methods=["POST"])
def scan_fields():
    try:
        with _lock:
            if state["driver"] is None:
                raise RuntimeError("Launch the browser first.")
            fields = core.discover_fields(state["driver"], log=log)
            state["fields"] = fields
            state["fields_by_id"] = {f.element_id: f for f in fields}
        log(f"Discovered {len(fields)} fields.")
        return jsonify({"ok": True, "fields": [field_to_dict(f) for f in fields]})
    except Exception as e:
        return error_response(e)


# ---------------------------------------------------------------------------
# Excel
# ---------------------------------------------------------------------------
@app.route("/api/upload-excel", methods=["POST"])
def upload_excel():
    try:
        f = request.files.get("file")
        if not f:
            raise RuntimeError("No file uploaded.")
        dest = UPLOAD_DIR / f.filename
        f.save(dest)
        sheets = core.list_sheets(str(dest))
        with _lock:
            state["excel_path"] = str(dest)
            state["excel_key"] = f.filename
            state["sheets"] = sheets
            # bring forward any previously saved mapping for this file
            state["mapping"] = (
                state["all_mappings"].get(f.filename)
                or state["all_mappings"].pop("_legacy", {})
                or {}
            )
        log(f"Uploaded '{f.filename}'. Sheets: {sheets}")
        return jsonify({"ok": True, "sheets": sheets, "filename": f.filename})
    except Exception as e:
        return error_response(e)


@app.route("/api/load-sheet", methods=["POST"])
def load_sheet():
    try:
        data = request.get_json(force=True)
        sheet = data.get("sheet")
        with _lock:
            if not state["excel_path"]:
                raise RuntimeError("Upload an Excel file first.")
            df = core.load_excel(state["excel_path"], sheet)
            state["df"] = df
        preview = df.head(20).where(pd.notnull(df.head(20)), None).to_dict(orient="records")
        log(f"Loaded {len(df)} rows, columns: {list(df.columns)}")
        return jsonify(
            {
                "ok": True,
                "columns": list(df.columns),
                "row_count": len(df),
                "preview": preview,
            }
        )
    except Exception as e:
        return error_response(e)


# ---------------------------------------------------------------------------
# Mapping
# ---------------------------------------------------------------------------
@app.route("/api/suggest-mapping", methods=["POST"])
def suggest_mapping():
    try:
        with _lock:
            if state["df"] is None:
                raise RuntimeError("Load an Excel sheet first.")
            if not state["fields"]:
                raise RuntimeError("Scan the form fields first.")
            mapping = core.suggest_mapping(list(state["df"].columns), state["fields"], state["learned"])
            state["mapping"] = mapping
        log("Auto-suggested a field mapping. Please review it before running.")
        return jsonify({"ok": True, "mapping": mapping})
    except Exception as e:
        return error_response(e)


@app.route("/api/mapping", methods=["GET", "POST"])
def mapping_endpoint():
    if request.method == "GET":
        with _lock:
            required_unmapped = [
                f.label
                for f in state["fields"]
                if f.required and f.element_id not in state["mapping"].values()
            ]
            return jsonify(
                {
                    "ok": True,
                    "mapping": state["mapping"],
                    "required_unmapped": required_unmapped,
                }
            )
    data = request.get_json(force=True)
    with _lock:
        state["mapping"] = data.get("mapping", {})
    return jsonify({"ok": True})


@app.route("/api/save-mapping", methods=["POST"])
def save_mapping():
    try:
        with _lock:
            if not state["excel_key"]:
                raise RuntimeError("Upload an Excel file first.")
            state["all_mappings"][state["excel_key"]] = state["mapping"]
            core.save_all_mappings(state["all_mappings"])
            core.update_learned(
                state["learned"], list(state["df"].columns), state["mapping"], state["fields_by_id"]
            )
        log(f"Mapping for '{state['excel_key']}' saved (and learned for future files).")
        return jsonify({"ok": True})
    except Exception as e:
        return error_response(e)


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------
def _row_payload():
    df = state["df"]
    idx = state["current_idx"]
    if df is None or idx >= len(df):
        return {"finished": True, "index": idx, "total": 0 if df is None else len(df)}
    row = df.iloc[idx]
    return {
        "finished": False,
        "index": idx,
        "total": len(df),
        "redo_count": state["redo_count"],
        "row": {col: row.get(col) for col in df.columns},
    }


@app.route("/api/start-run", methods=["POST"])
def start_run():
    try:
        with _lock:
            if state["df"] is None or not state["mapping"]:
                raise RuntimeError("Load Excel data and save a mapping first.")
            if state["driver"] is None or not state["fields"]:
                raise RuntimeError("Launch the browser and scan fields first.")
            state["done_indices"] = core.load_done_rows(state["excel_key"])
            pending = [i for i in range(len(state["df"])) if i not in state["done_indices"]]
            state["current_idx"] = pending[0] if pending else 0
            state["redo_count"] = 0
        log(
            f"Run ready. {len(state['df'])} total rows, {len(state['done_indices'])} already done, "
            f"{len(pending)} pending."
        )
        return jsonify({"ok": True, **_row_payload()})
    except Exception as e:
        return error_response(e)


@app.route("/api/current-row", methods=["GET"])
def current_row():
    with _lock:
        return jsonify({"ok": True, **_row_payload()})


@app.route("/api/jump-row", methods=["POST"])
def jump_row():
    data = request.get_json(force=True)
    n = int(data.get("row", 1))
    with _lock:
        if state["df"] is None:
            return error_response(RuntimeError("No data loaded."))
        n = max(1, min(n, len(state["df"])))
        state["current_idx"] = n - 1
        state["redo_count"] = 0
    return jsonify({"ok": True, **_row_payload()})


@app.route("/api/fill-row", methods=["POST"])
def fill_row_endpoint():
    try:
        with _lock:
            df = state["df"]
            idx = state["current_idx"]
            if df is None or idx >= len(df):
                raise RuntimeError("No current row to fill.")
            row = df.iloc[idx]
            errors = core.fill_row(state["driver"], row, state["mapping"], state["fields_by_id"])
        if errors:
            log(f"Row {idx + 1}: errors while filling:")
            for e in errors:
                log(f"   - {e}")
        else:
            log(f"Row {idx + 1} filled. Review in the browser, then submit.")
        return jsonify({"ok": True, "errors": errors})
    except Exception as e:
        return error_response(e)


@app.route("/api/redo-row", methods=["POST"])
def redo_row():
    with _lock:
        state["redo_count"] += 1
    log(f"Redoing row {state['current_idx'] + 1} (retyping all mapped fields)...")
    return fill_row_endpoint()


@app.route("/api/click-submit", methods=["POST"])
def click_submit_endpoint():
    try:
        data = request.get_json(force=True)
        submit_id = (data.get("submit_id") or "").strip()
        if not submit_id:
            raise RuntimeError("No submit button element id given.")
        with _lock:
            core.click_submit(state["driver"], submit_id)
        log("Submit button clicked.")
        return jsonify({"ok": True})
    except Exception as e:
        return error_response(e)


def _advance(status: str, detail: str):
    with _lock:
        idx = state["current_idx"]
        core.append_log_row(state["excel_key"], idx, status, detail)
        state["done_indices"].add(idx)
        state["redo_count"] = 0
        state["current_idx"] += 1
        while state["current_idx"] < len(state["df"]) and state["current_idx"] in state["done_indices"]:
            state["current_idx"] += 1
    log(f"Row {idx + 1}: {status} ({detail})")
    return _row_payload()


@app.route("/api/mark-done", methods=["POST"])
def mark_done():
    try:
        with _lock:
            detail = "manually submitted"
            if state["redo_count"]:
                detail += f" (after {state['redo_count']} redo(s))"
        return jsonify({"ok": True, **_advance("done", detail)})
    except Exception as e:
        return error_response(e)


@app.route("/api/skip-row", methods=["POST"])
def skip_row():
    try:
        return jsonify({"ok": True, **_advance("skipped", "user skipped")})
    except Exception as e:
        return error_response(e)


@app.route("/api/redo-previous", methods=["POST"])
def redo_previous():
    try:
        with _lock:
            prev_idx = state["current_idx"] - 1
            if prev_idx < 0:
                raise RuntimeError("There is no previous row.")
            core.remove_last_log_entry(state["excel_key"], prev_idx)
            state["done_indices"].discard(prev_idx)
            state["current_idx"] = prev_idx
            state["redo_count"] = 0
        log(f"Reopened row {prev_idx + 1} for redo.")
        return jsonify({"ok": True, **_row_payload()})
    except Exception as e:
        return error_response(e)



# ---------------------------------------------------------------------------
# Google Sheets (live data source)
# ---------------------------------------------------------------------------
@app.route("/api/gsheet-tabs", methods=["POST"])
def gsheet_tabs():
    try:
        data = request.get_json(force=True) or {}
        url = data.get("url", "").strip()
        if not url:
            raise RuntimeError("No URL provided.")
        tabs = core.list_google_sheet_tabs(url, log=log)
        return jsonify({"ok": True, "tabs": tabs})
    except Exception as e:
        return error_response(e)


@app.route("/api/load-gsheet", methods=["POST"])
def load_gsheet():
    try:
        data = request.get_json(force=True) or {}
        url  = data.get("url", "").strip()
        gid  = str(data.get("gid", "0"))
        tab_title = data.get("tab_title", "Sheet1")
        if not url:
            raise RuntimeError("No URL provided.")

        import re as _re
        base_url = _re.sub(r"[#&?]gid=\d+", "", url)
        resolved_url = base_url + f"#gid={gid}"

        df = core.load_google_sheet(resolved_url, log=log)
        label = f"gsheet:{tab_title}"
        with _lock:
            state["df"]        = df
            state["excel_key"] = label
            state["mapping"]   = state["all_mappings"].get(label, {})

        preview = df.head(20).where(pd.notnull(df.head(20)), None).to_dict(orient="records")
        log(f"Loaded {len(df)} rows from Google Sheets tab '{tab_title}'.")
        return jsonify({
            "ok": True,
            "columns": list(df.columns),
            "row_count": len(df),
            "preview": preview,
            "excel_key": label,
        })
    except Exception as e:
        return error_response(e)


@app.route("/api/refresh-gsheet", methods=["POST"])
def refresh_gsheet():
    try:
        data = request.get_json(force=True) or {}
        url  = data.get("url", "").strip()
        gid  = str(data.get("gid", "0"))
        tab_title = data.get("tab_title", "Sheet1")
        if not url:
            raise RuntimeError("No URL provided.")

        import re as _re
        base_url = _re.sub(r"[#&?]gid=\d+", "", url)
        resolved_url = base_url + f"#gid={gid}"

        df = core.load_google_sheet(resolved_url, log=log)
        with _lock:
            prev_len = len(state["df"]) if state["df"] is not None else 0
            state["df"] = df

        delta = len(df) - prev_len
        delta_str = f" (+{delta} new rows)" if delta > 0 else ""
        log(f"Refreshed Google Sheet: {len(df)} rows{delta_str}.")
        return jsonify({
            "ok": True,
            "columns": list(df.columns),
            "row_count": len(df),
            "delta": delta,
        })
    except Exception as e:
        return error_response(e)

# ---------------------------------------------------------------------------
# Logs / state polling
# ---------------------------------------------------------------------------
@app.route("/api/logs", methods=["GET"])
def get_logs():
    since = int(request.args.get("since", 0))
    with _lock:
        entries = [e for e in state["logs"] if e["id"] > since]
    return jsonify({"ok": True, "logs": entries})


@app.route("/api/state", methods=["GET"])
def get_state():
    with _lock:
        return jsonify(
            {
                "ok": True,
                "browser_open": state["driver"] is not None,
                "fields": [field_to_dict(f) for f in state["fields"]],
                "excel_key": state["excel_key"],
                "sheets": state["sheets"],
                "columns": list(state["df"].columns) if state["df"] is not None else [],
                "row_count": len(state["df"]) if state["df"] is not None else 0,
                "mapping": state["mapping"],
            }
        )


def run(host="127.0.0.1", port=5000, debug=False, open_browser=True):
    import webbrowser, threading
    url = f"http://{host}:{port}"
    if open_browser:
        # Open after a short delay so Flask is ready
        threading.Timer(1.2, lambda: webbrowser.open(url)).start()
    print(f"\n  ✦  NIELIT Data Entry Agent")
    print(f"  →  Open in browser: {url}\n")
    app.run(host=host, port=port, debug=debug, threaded=True)
