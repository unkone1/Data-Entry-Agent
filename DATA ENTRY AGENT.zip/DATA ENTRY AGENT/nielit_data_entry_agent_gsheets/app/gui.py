"""
gui.py
======
A modern, themed desktop UI for the NIELIT Data Entry Agent, built with
ttkbootstrap on top of Tkinter.

Flow (as tabs, left to right):
  1. Browser   -- launch Chrome, let the user log in / navigate manually,
                  then scan the page for fillable fields.
  2. Excel     -- pick the spreadsheet and sheet to load.
  3. Mapping   -- review / fix which Excel column goes into which form field.
  4. Run       -- step through rows one at a time, fill, review, submit
                  yourself, redo, skip, or stop -- with full logging.

Nothing here ever pastes into the page; typing is done character-by-character
via Selenium, same as the original script. All CAPTCHA / login / final
"Submit" clicks are left to the human by default.
"""

from __future__ import annotations

import os
import queue
import threading
import tkinter as tk
from typing import Optional

import ttkbootstrap as ttkb
from ttkbootstrap.constants import *  # noqa: F401,F403
from ttkbootstrap.dialogs import Messagebox, Querybox

from . import core

APP_NAME = "NIELIT Gangtok Data Entry Agent"
APP_TAGLINE = "Excel \u2192 Web Form, typed by hand \u2014 not pasted"
AUTHOR_CREDIT = "made by @binash"
DEFAULT_START_URL = "https://student.nielit.gov.in/"
THEME = "darkly"


class DataEntryApp(ttkb.Window):
    def __init__(self):
        super().__init__(title=APP_NAME, themename=THEME, size=(1080, 760), minsize=(940, 660))
        self.position_center()

        # ---- shared state ----
        self.driver = None
        self.fields: list[core.FormField] = []
        self.fields_by_id: dict[str, core.FormField] = {}

        self.excel_path: Optional[str] = None
        self.excel_key: Optional[str] = None
        self.df = None
        self.mapping: dict[str, str] = {}
        self.all_mappings = core.load_all_mappings()
        self.learned = core.load_learned()

        self.done_indices: set[int] = set()
        self.current_idx = 0
        self.redo_count = 0

        self.log_queue: "queue.Queue[tuple[str, str]]" = queue.Queue()

        self._build_ui()
        self._poll_log_queue()

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        self._apply_custom_styles()
        self._build_header()

        body = ttkb.Frame(self)
        body.pack(fill="both", expand=True, padx=0, pady=0)

        self.notebook = ttkb.Notebook(body, bootstyle="primary")
        self.notebook.pack(fill="both", expand=True, padx=16, pady=(8, 0))

        self.tab_browser = ttkb.Frame(self.notebook, padding=16)
        self.tab_excel   = ttkb.Frame(self.notebook, padding=16)
        self.tab_mapping = ttkb.Frame(self.notebook, padding=16)
        self.tab_run     = ttkb.Frame(self.notebook, padding=16)

        self.notebook.add(self.tab_browser, text="  🌐  Browser  ")
        self.notebook.add(self.tab_excel,   text="  📊  Data Source  ")
        self.notebook.add(self.tab_mapping, text="  🔗  Field Mapping  ")
        self.notebook.add(self.tab_run,     text="  ▶  Run  ")

        self._build_browser_tab()
        self._build_excel_tab()
        self._build_mapping_tab()
        self._build_run_tab()
        self._build_status_bar()
        self._build_log_panel()

        # Animate header pulse on start
        self.after(300, self._pulse_header)

    def _apply_custom_styles(self):
        """Inject custom ttk styles for a more polished look."""
        style = ttkb.Style.get_instance()
        # Larger, bolder notebook tabs
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(14, 8))
        # Rounded buttons feel
        style.configure("TButton", font=("Segoe UI", 10), padding=(10, 6))
        # Labelframe titles
        style.configure("TLabelframe.Label", font=("Segoe UI", 9, "bold"))

    def _build_header(self):
        # Gradient-feel header using two stacked frames
        self.header_outer = tk.Frame(self, bg="#0d1117", height=72)
        self.header_outer.pack(fill="x")
        self.header_outer.pack_propagate(False)

        # Left: logo area
        left = tk.Frame(self.header_outer, bg="#0d1117")
        left.place(x=18, y=0, relheight=1)

        self._dot_canvas = tk.Canvas(left, width=44, height=44, bg="#0d1117", highlightthickness=0)
        self._dot_canvas.pack(side="left", padx=(0, 12), pady=14)
        self._dot_canvas.create_oval(4, 4, 40, 40, fill="#238636", outline="#2ea043", width=2, tags="dot")
        self._dot_anim_phase = 0

        name_frame = tk.Frame(left, bg="#0d1117")
        name_frame.pack(side="left", pady=10)
        tk.Label(
            name_frame, text=APP_NAME, bg="#0d1117", fg="#e6edf3",
            font=("Segoe UI", 15, "bold"),
        ).pack(anchor="w")
        tk.Label(
            name_frame, text=APP_TAGLINE, bg="#0d1117", fg="#8b949e",
            font=("Segoe UI", 9),
        ).pack(anchor="w")

        # Right: status chips
        right = tk.Frame(self.header_outer, bg="#0d1117")
        right.place(relx=1, x=-18, y=0, anchor="ne", relheight=1)

        chips_frame = tk.Frame(right, bg="#0d1117")
        chips_frame.pack(side="right", pady=18)

        self.dot_browser = self._hchip(chips_frame, "Browser")
        self.dot_excel   = self._hchip(chips_frame, "Data")
        self.dot_mapping = self._hchip(chips_frame, "Mapped")

        tk.Label(
            right, text=AUTHOR_CREDIT, bg="#0d1117", fg="#484f58",
            font=("Segoe UI", 8, "italic"),
        ).pack(side="right", padx=(0, 8), pady=(44, 0))

    def _hchip(self, parent, label: str):
        """Header status chip — returns the dot canvas for animation."""
        f = tk.Frame(parent, bg="#0d1117")
        f.pack(side="left", padx=10)
        c = tk.Canvas(f, width=10, height=10, bg="#0d1117", highlightthickness=0)
        c.pack(side="left", pady=2)
        c.create_oval(1, 1, 9, 9, fill="#30363d", outline="", tags="dot")
        tk.Label(f, text=label, bg="#0d1117", fg="#8b949e", font=("Segoe UI", 8)).pack(side="left", padx=(3, 0))
        return c

    def _set_chip(self, dot_canvas, ok: bool):
        color = "#2ea043" if ok else "#30363d"
        dot_canvas.itemconfigure("dot", fill=color)
        if ok:
            self._animate_chip_glow(dot_canvas, 0)

    def _animate_chip_glow(self, canvas, step):
        """Brief glow pulse when a chip turns green."""
        colors = ["#3fb950", "#56d364", "#3fb950", "#2ea043"]
        if step < len(colors):
            canvas.itemconfigure("dot", fill=colors[step])
            self.after(80, lambda: self._animate_chip_glow(canvas, step + 1))

    def _pulse_header(self):
        """Subtle pulsing glow on the header dot."""
        sizes = [(4,40), (3,41), (2,42), (3,41), (4,40)]
        phase = self._dot_anim_phase % len(sizes)
        s, e = sizes[phase]
        self._dot_canvas.coords("dot", s, s, e, e)
        self._dot_anim_phase += 1
        self.after(600, self._pulse_header)

    def _build_status_bar(self):
        bar = tk.Frame(self, bg="#161b22", height=38)
        bar.pack(fill="x", padx=0)
        bar.pack_propagate(False)

        inner = tk.Frame(bar, bg="#161b22")
        inner.pack(fill="x", padx=16, pady=6)

        self.run_meter_label_var = tk.StringVar(value="No run started")
        tk.Label(
            inner, textvariable=self.run_meter_label_var,
            bg="#161b22", fg="#8b949e", font=("Segoe UI", 9),
        ).pack(side="left")

        # Progress bar embedded in status bar
        self.status_progress = ttkb.Progressbar(
            inner, mode="determinate", bootstyle="success", length=200,
        )
        self.status_progress.pack(side="left", padx=16)
        self.status_progress["value"] = 0

        self.busy_bar = ttkb.Progressbar(inner, mode="indeterminate", bootstyle="info-striped", length=120)
        # packed/unpacked dynamically

    def _set_busy(self, busy: bool):
        if busy:
            self.busy_bar.pack(side="right", padx=8)
            self.busy_bar.start(10)
        else:
            self.busy_bar.stop()
            self.busy_bar.pack_forget()

    def _build_log_panel(self):
        outer = tk.Frame(self, bg="#0d1117")
        outer.pack(fill="x", padx=0, pady=0)

        header_row = tk.Frame(outer, bg="#161b22")
        header_row.pack(fill="x")
        tk.Label(
            header_row, text="  Activity Log", bg="#161b22", fg="#8b949e",
            font=("Segoe UI", 8, "bold"),
        ).pack(side="left", pady=4)
        tk.Label(
            header_row, text=f"{APP_NAME}  •  {AUTHOR_CREDIT}",
            bg="#161b22", fg="#30363d", font=("Segoe UI", 7),
        ).pack(side="right", padx=12, pady=4)

        text_wrap = tk.Frame(outer, bg="#0d1117")
        text_wrap.pack(fill="x")

        self.log_text = tk.Text(
            text_wrap, height=7, wrap="word", state="disabled",
            background="#0d1117", foreground="#c9d1d9",
            font=("Consolas", 9),
            relief="flat", borderwidth=0,
            padx=16, pady=8,
            insertbackground="#c9d1d9",
        )
        self.log_text.pack(fill="x", side="left", expand=True)
        self.log_text.tag_configure("info",    foreground="#8b949e")
        self.log_text.tag_configure("success", foreground="#3fb950")
        self.log_text.tag_configure("error",   foreground="#f85149")
        self.log_text.tag_configure("warn",    foreground="#d29922")
        self.log_text.tag_configure("ts",      foreground="#484f58")

        scroll = ttkb.Scrollbar(text_wrap, command=self.log_text.yview, bootstyle="round-dark")
        scroll.pack(side="right", fill="y")
        self.log_text["yscrollcommand"] = scroll.set

    # -- Tab 1: Browser --------------------------------------------------
    def _build_browser_tab(self):
        f = self.tab_browser

        # Step card
        card = self._section_card(f, "🌐  Open the form")
        card.pack(fill="x", pady=(0, 12))

        row = ttkb.Frame(card)
        row.pack(fill="x")
        ttkb.Label(row, text="Start URL", bootstyle="secondary").pack(side="left")
        self.url_var = tk.StringVar(value=DEFAULT_START_URL)
        e = ttkb.Entry(row, textvariable=self.url_var, width=52, bootstyle="info")
        e.pack(side="left", padx=8)
        self.btn_launch = ttkb.Button(
            row, text="🚀  Launch Chrome", command=self.on_launch_browser, bootstyle="success"
        )
        self.btn_launch.pack(side="left", padx=6)
        self._bind_hover(self.btn_launch, "success")

        ttkb.Label(
            card,
            text="After Chrome opens: log in, solve any CAPTCHA, and navigate to the exact form page. Then come back and click Scan Form Fields.",
            justify="left", bootstyle="secondary",
        ).pack(anchor="w", pady=(12, 0))

        card2 = self._section_card(f, "🔍  Discover fields")
        card2.pack(fill="both", expand=True)

        scan_row = ttkb.Frame(card2)
        scan_row.pack(fill="x", pady=(0, 10))
        self.btn_scan = ttkb.Button(
            scan_row, text="🔍  Scan Form Fields", command=self.on_scan_fields,
            state="disabled", bootstyle="primary",
        )
        self.btn_scan.pack(side="left")
        self._bind_hover(self.btn_scan, "primary")

        self.scan_status_var = tk.StringVar(value="")
        ttkb.Label(scan_row, textvariable=self.scan_status_var, bootstyle="secondary",
                   font=("Segoe UI", 9)).pack(side="left", padx=12)

        cols = ("field",)
        self.fields_tree = ttkb.Treeview(card2, columns=cols, show="headings", height=13, bootstyle="info")
        self.fields_tree.heading("field", text="Discovered form field")
        self.fields_tree.column("field", width=760)
        self.fields_tree.pack(fill="both", expand=True)

    # -- Tab 2: Excel / Google Sheets ------------------------------------
    def _build_excel_tab(self):
        f = self.tab_excel

        src_card = self._section_card(f, "Choose data source")
        src_card.pack(fill="x", pady=(0, 8))

        self.data_source_var = tk.StringVar(value="excel")

        rb_row = ttkb.Frame(src_card)
        rb_row.pack(fill="x", pady=(0, 10))
        ttkb.Radiobutton(
            rb_row, text="📂  Local Excel File", variable=self.data_source_var,
            value="excel", bootstyle="primary", command=self._on_source_toggle,
        ).pack(side="left", padx=(0, 24))
        ttkb.Radiobutton(
            rb_row, text="🌐  Google Sheets (live)", variable=self.data_source_var,
            value="gsheet", bootstyle="success", command=self._on_source_toggle,
        ).pack(side="left")

        # Excel section
        self.excel_frame = ttkb.Frame(src_card)
        self.excel_frame.pack(fill="x")

        ef_row = ttkb.Frame(self.excel_frame)
        ef_row.pack(fill="x")
        btn_choose = ttkb.Button(
            ef_row, text="📂  Choose Excel File...", command=self.on_choose_excel, bootstyle="primary"
        )
        btn_choose.pack(side="left")
        self._bind_hover(btn_choose, "primary")
        self.excel_path_var = tk.StringVar(value="(no file selected)")
        ttkb.Label(ef_row, textvariable=self.excel_path_var, bootstyle="secondary",
                   font=("Segoe UI", 9)).pack(side="left", padx=10)

        ef_row2 = ttkb.Frame(self.excel_frame)
        ef_row2.pack(fill="x", pady=(8, 0))
        ttkb.Label(ef_row2, text="Sheet", bootstyle="secondary").pack(side="left")
        self.sheet_var = tk.StringVar()
        self.sheet_combo = ttkb.Combobox(ef_row2, textvariable=self.sheet_var, state="readonly", width=28)
        self.sheet_combo.pack(side="left", padx=8)
        self.btn_load_excel = ttkb.Button(
            ef_row2, text="✅  Load Sheet", command=self.on_load_excel_sheet,
            state="disabled", bootstyle="success",
        )
        self.btn_load_excel.pack(side="left", padx=6)

        # Google Sheets section
        self.gsheet_frame = ttkb.Frame(src_card)

        gs_row1 = ttkb.Frame(self.gsheet_frame)
        gs_row1.pack(fill="x")
        ttkb.Label(gs_row1, text="Sheet URL", bootstyle="secondary").pack(side="left")
        self.gsheet_url_var = tk.StringVar()
        ttkb.Entry(gs_row1, textvariable=self.gsheet_url_var, width=56, bootstyle="info").pack(side="left", padx=8)
        btn_ft = ttkb.Button(gs_row1, text="🔍  Fetch Tabs", command=self.on_fetch_gsheet_tabs, bootstyle="primary")
        btn_ft.pack(side="left", padx=4)
        self._bind_hover(btn_ft, "primary")

        ttkb.Label(
            self.gsheet_frame,
            text="File → Share → Publish to web → CSV. Then paste the published link here.",
            bootstyle="secondary", font=("Segoe UI", 8),
        ).pack(anchor="w", pady=(6, 4))

        gs_row2 = ttkb.Frame(self.gsheet_frame)
        gs_row2.pack(fill="x", pady=(4, 0))
        ttkb.Label(gs_row2, text="Tab", bootstyle="secondary").pack(side="left")
        self.gsheet_tab_var = tk.StringVar()
        self.gsheet_tab_combo = ttkb.Combobox(gs_row2, textvariable=self.gsheet_tab_var, state="readonly", width=28)
        self.gsheet_tab_combo.pack(side="left", padx=8)
        self.btn_load_gsheet = ttkb.Button(
            gs_row2, text="✅  Load", command=self.on_load_gsheet, state="disabled", bootstyle="success",
        )
        self.btn_load_gsheet.pack(side="left", padx=6)
        self.btn_refresh_gsheet = ttkb.Button(
            gs_row2, text="🔄  Refresh", command=self.on_refresh_gsheet, state="disabled", bootstyle="info",
        )
        self.btn_refresh_gsheet.pack(side="left", padx=6)
        ttkb.Label(gs_row2, text="← pull latest rows anytime", bootstyle="secondary",
                   font=("Segoe UI", 8)).pack(side="left", padx=6)

        self._gsheet_tabs: list = []

        # Preview
        prev_card = self._section_card(f, "Preview — first 20 rows")
        prev_card.pack(fill="both", expand=True)
        self.preview_tree = ttkb.Treeview(prev_card, show="headings", height=14, bootstyle="info")
        self.preview_tree.pack(fill="both", expand=True)

    # -- Tab 3: Mapping --------------------------------------------------
    def _build_mapping_tab(self):
        f = self.tab_mapping

        top = ttkb.Frame(f)
        top.pack(fill="x", pady=(0, 10))
        btn_auto = ttkb.Button(top, text="✨  Auto-suggest Mapping", command=self.on_autosuggest, bootstyle="primary")
        btn_auto.pack(side="left")
        self._bind_hover(btn_auto, "primary")
        btn_save = ttkb.Button(top, text="💾  Save Mapping", command=self.on_save_mapping, bootstyle="success")
        btn_save.pack(side="left", padx=10)
        self._bind_hover(btn_save, "success")
        ttkb.Label(
            top,
            text="Double-click a row to change which Excel column fills that form field.",
            bootstyle="secondary", font=("Segoe UI", 9),
        ).pack(side="left", padx=12)

        map_card = self._section_card(f, "Mapping — Excel column  →  form field")
        map_card.pack(fill="both", expand=True)
        self.mapping_tree = ttkb.Treeview(
            map_card, columns=("field", "col"), show="headings", height=18, bootstyle="info"
        )
        self.mapping_tree.heading("field", text="Form field (HTML id/name)")
        self.mapping_tree.heading("col",   text="Excel / Sheet column")
        self.mapping_tree.column("field", width=380)
        self.mapping_tree.column("col",   width=360)
        self.mapping_tree.pack(fill="both", expand=True)
        self.mapping_tree.bind("<Double-1>", self.on_edit_mapping_row)

    # -- Tab 4: Run ------------------------------------------------------
    def _build_run_tab(self):
        f = self.tab_run

        # Settings card
        settings_card = self._section_card(f, "Settings")
        settings_card.pack(fill="x", pady=(0, 10))
        self.auto_submit_var = tk.BooleanVar(value=False)
        ttkb.Checkbutton(
            settings_card, text="Auto-click submit after each row",
            variable=self.auto_submit_var, bootstyle="warning-round-toggle",
        ).pack(side="left")
        ttkb.Label(settings_card, text="   Submit button id:", bootstyle="secondary").pack(side="left")
        self.submit_id_var = tk.StringVar()
        ttkb.Entry(settings_card, textvariable=self.submit_id_var, width=22, bootstyle="info").pack(side="left", padx=6)

        # Action buttons
        btn_row = ttkb.Frame(f)
        btn_row.pack(fill="x", pady=(0, 8))
        self.btn_start = ttkb.Button(btn_row, text="▶  Start / Resume", command=self.on_start_run, bootstyle="success")
        self.btn_start.pack(side="left")
        self._bind_hover(self.btn_start, "success")
        btn_jump = ttkb.Button(btn_row, text="🔢  Jump to row...", command=self.on_jump_to_row, bootstyle="secondary")
        btn_jump.pack(side="left", padx=8)
        self._bind_hover(btn_jump, "secondary")

        # Animated progress label
        self.progress_var = tk.StringVar(value="No run started.")
        self._progress_label = ttkb.Label(
            f, textvariable=self.progress_var, font=("Segoe UI", 13, "bold"), bootstyle="primary"
        )
        self._progress_label.pack(anchor="w", pady=(0, 6))

        # Current row card
        row_card = self._section_card(f, "Current row")
        row_card.pack(fill="both", expand=True, pady=(0, 8))
        self.row_tree = ttkb.Treeview(row_card, columns=("col", "val"), show="headings", height=8, bootstyle="info")
        self.row_tree.heading("col", text="Column")
        self.row_tree.heading("val", text="Value")
        self.row_tree.column("col", width=200)
        self.row_tree.column("val", width=500)
        self.row_tree.pack(fill="both", expand=True)

        # Action buttons — fill / redo / submit / mark / skip
        btns = ttkb.Frame(f)
        btns.pack(fill="x")
        self.btn_fill = ttkb.Button(btns, text="✍  Fill Row", command=self.on_fill_row, state="disabled", bootstyle="primary")
        self.btn_fill.pack(side="left")
        self._bind_hover(self.btn_fill, "primary")

        self.btn_redo = ttkb.Button(btns, text="🔁  Redo", command=self.on_redo_row, state="disabled", bootstyle="warning")
        self.btn_redo.pack(side="left", padx=6)

        self.btn_submit_click = ttkb.Button(btns, text="⚠  Click Submit", command=self.on_click_submit, state="disabled", bootstyle="danger")
        self.btn_submit_click.pack(side="left", padx=6)

        self.btn_mark_done = ttkb.Button(btns, text="✓  Mark Done → Next", command=self.on_mark_done_next, state="disabled", bootstyle="success")
        self.btn_mark_done.pack(side="left", padx=6)
        self._bind_hover(self.btn_mark_done, "success")

        self.btn_skip = ttkb.Button(btns, text="⏭  Skip", command=self.on_skip_row, state="disabled", bootstyle="secondary")
        self.btn_skip.pack(side="left", padx=6)

        self.btn_redo_prev = ttkb.Button(btns, text="↩  Redo Previous", command=self.on_redo_previous, state="disabled", bootstyle="warning-outline")
        self.btn_redo_prev.pack(side="left", padx=6)

    # ------------------------------------------------------------------
    # Design helpers
    # ------------------------------------------------------------------
    def _section_card(self, parent, title: str) -> ttkb.Frame:
        """A clean labeled card with a subtle border."""
        return ttkb.Labelframe(parent, text=" " + title + " ", padding=12, bootstyle="secondary")

    def _bind_hover(self, btn: ttkb.Button, style: str):
        """Subtle scale-on-hover via font weight toggle — pure Tk, no extra libs."""
        def on_enter(e):
            try:
                btn.configure(cursor="hand2")
            except Exception:
                pass
        def on_leave(e):
            try:
                btn.configure(cursor="")
            except Exception:
                pass
        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)

    def _flash_label(self, label: ttkb.Label, styles: list, idx: int = 0):
        """Cycle through bootstyles for a brief flash animation."""
        if idx < len(styles):
            label.configure(bootstyle=styles[idx])
            self.after(120, lambda: self._flash_label(label, styles, idx + 1))

    # ------------------------------------------------------------------
    # Logging helpers (thread-safe via queue)
    # ------------------------------------------------------------------
    def log(self, msg: str, level: str = "info"):
        self.log_queue.put((str(msg), level))

    def _poll_log_queue(self):
        try:
            while True:
                msg, level = self.log_queue.get_nowait()
                self.log_text.configure(state="normal")
                self.log_text.insert("end", msg + "\n", level)
                self.log_text.see("end")
                self.log_text.configure(state="disabled")
        except queue.Empty:
            pass
        self.after(150, self._poll_log_queue)

    def run_in_thread(self, target, on_done=None, on_error=None, busy=True):
        """Run `target` (a zero-arg callable) in a background thread so the
        GUI doesn't freeze, then marshal the result back to the main thread."""
        if busy:
            self._set_busy(True)

        def worker():
            try:
                result = target()
            except Exception as e:  # noqa: BLE001
                # IMPORTANT: capture `e` into a default arg NOW, before Python
                # clears the except-variable when the except block exits (PEP 3110).
                captured = e
                self.after(0, lambda exc=captured: self._finish(
                    False, lambda x=exc: (on_error(x) if on_error else self._default_error(x))
                ))
                return
            self.after(0, lambda r=result: self._finish(True, lambda: (on_done(r) if on_done else None)))

        threading.Thread(target=worker, daemon=True).start()

    def _finish(self, ok: bool, callback):
        self._set_busy(False)
        callback()

    def _default_error(self, e: Exception):
        self.log(f"ERROR: {e}", "error")
        Messagebox.show_error(str(e), title="Error")

    # ------------------------------------------------------------------
    # Tab 1 handlers
    # ------------------------------------------------------------------
    def on_launch_browser(self):
        self.btn_launch.configure(state="disabled")
        self.log("Launching Chrome...", "info")

        def task():
            from selenium import webdriver

            options = webdriver.ChromeOptions()
            options.add_experimental_option("detach", True)
            chromedriver_path = os.environ.get("CHROMEDRIVER_PATH")
            if chromedriver_path:
                driver = webdriver.Chrome(
                    service=webdriver.ChromeService(chromedriver_path), options=options
                )
            else:
                driver = webdriver.Chrome(options=options)
            driver.get(self.url_var.get().strip() or DEFAULT_START_URL)
            return driver

        def done(driver):
            self.driver = driver
            self._set_chip(self.dot_browser, True)
            self.log("Chrome opened. Log in / navigate to the form, then click 'Scan Form Fields'.", "success")
            self.btn_scan.configure(state="normal")
            self.btn_launch.configure(state="normal")

        def err(e):
            self.btn_launch.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    def on_scan_fields(self):
        if not self.driver:
            Messagebox.show_warning("Launch Chrome first.", title="No browser")
            return
        self.btn_scan.configure(state="disabled")
        self.log("Scanning page for form fields...", "info")

        def task():
            return core.discover_fields(self.driver, log=lambda m: self.log(m, "warn"))

        def done(fields):
            self.btn_scan.configure(state="normal")
            self.fields = fields
            self.fields_by_id = {f.element_id: f for f in fields}
            self.fields_tree.delete(*self.fields_tree.get_children())
            for fld in fields:
                self.fields_tree.insert("", "end", values=(fld.display,))
            self.log(f"Discovered {len(fields)} fields.", "success" if fields else "warn")
            if not fields:
                Messagebox.show_warning(
                    "No fillable fields were found on this page. Make sure the "
                    "form is fully loaded and visible, then try again.",
                    title="No fields found",
                )

        def err(e):
            self.btn_scan.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    # ------------------------------------------------------------------
    # Tab 2 handlers – source toggle
    # ------------------------------------------------------------------
    def _on_source_toggle(self):
        """Show/hide Excel-file vs Google Sheets widgets based on radio selection."""
        if self.data_source_var.get() == "gsheet":
            self.excel_frame.pack_forget()
            self.gsheet_frame.pack(fill="x")
        else:
            self.gsheet_frame.pack_forget()
            self.excel_frame.pack(fill="x")

    # -- Google Sheets handlers ------------------------------------------
    def on_fetch_gsheet_tabs(self):
        url = self.gsheet_url_var.get().strip()
        if not url:
            Messagebox.show_warning("Paste a Google Sheets URL first.", title="No URL")
            return
        self.log("Fetching sheet tab list...", "info")

        def task():
            return core.list_google_sheet_tabs(url, log=lambda m: self.log(m, "info"))

        def done(tabs):
            self._gsheet_tabs = tabs
            names = [t["title"] for t in tabs]
            self.gsheet_tab_combo["values"] = names
            if names:
                self.gsheet_tab_var.set(names[0])
            self.btn_load_gsheet.configure(state="normal")
            self.log(f"Found {len(tabs)} tab(s): {names}", "success")

        def err(e):
            self.log(f"ERROR fetching tabs: {e}", "error")
            from ttkbootstrap.dialogs import Messagebox
            Messagebox.show_error(str(e), title="Could not fetch tabs")

        self.run_in_thread(task, done, err)

    def on_load_gsheet(self):
        url = self.gsheet_url_var.get().strip()
        if not url:
            Messagebox.show_warning("Enter a Google Sheets URL first.", title="No URL")
            return

        # Resolve the gid for the selected tab
        selected_title = self.gsheet_tab_var.get()
        gid = "0"
        for t in self._gsheet_tabs:
            if t["title"] == selected_title:
                gid = t["gid"]
                break

        # Build the URL with the correct gid embedded so core can parse it
        import re
        base_url = re.sub(r"[#&?]gid=\d+", "", url)
        resolved_url = base_url + f"#gid={gid}"

        self.log(f"Loading Google Sheet tab '{selected_title}' (gid={gid})...", "info")
        self._do_load_gsheet(resolved_url, label=f"gsheet:{selected_title}")

    def on_refresh_gsheet(self):
        """Re-fetch the same Google Sheet tab and update df in place."""
        url = self.gsheet_url_var.get().strip()
        if not url:
            return
        selected_title = self.gsheet_tab_var.get()
        import re
        gid = "0"
        for t in self._gsheet_tabs:
            if t["title"] == selected_title:
                gid = t["gid"]
                break
        base_url = re.sub(r"[#&?]gid=\d+", "", url)
        resolved_url = base_url + f"#gid={gid}"

        self.log(f"Refreshing data from Google Sheet (tab='{selected_title}')...", "info")

        def task():
            return core.load_google_sheet(resolved_url, log=lambda m: self.log(m, "info"))

        def done(df):
            prev_len = len(self.df) if self.df is not None else 0
            self.df = df
            # Reload done-row tracking so newly added rows appear as pending
            if self.excel_key:
                self.done_indices = core.load_done_rows(self.excel_key)
            self._update_preview(df)
            delta = len(df) - prev_len
            delta_str = f" (+{delta} new rows)" if delta > 0 else (f" ({delta} rows removed)" if delta < 0 else "")
            self.log(
                f"Refreshed: {len(df)} rows now loaded{delta_str}. "
                "Resume the run to process any newly added rows.",
                "success",
            )

        def err(e):
            self.log(f"ERROR refreshing Google Sheet: {e}", "error")
            Messagebox.show_error(str(e), title="Refresh Error")

        self.run_in_thread(task, done, err)

    def _do_load_gsheet(self, url: str, label: str):
        """Shared loader: fetch a Google Sheet and populate the app state."""
        def task():
            return core.load_google_sheet(url, log=lambda m: self.log(m, "info"))

        def done(df):
            self.df = df
            self.excel_key = label
            self._set_chip(self.dot_excel, True)
            self.log(f"Loaded {len(df)} rows, columns: {list(df.columns)}", "success")
            self._update_preview(df)
            self.mapping = self.all_mappings.get(self.excel_key, {})
            self._refresh_mapping_table()
            self.btn_refresh_gsheet.configure(state="normal")
            Messagebox.show_info(
                f"Loaded {len(df)} rows from Google Sheets.\n\n"
                "The data is live — click 'Refresh Data' at any time\n"
                "to pull the latest rows without restarting the run.\n\n"
                "Go to 'Field Mapping' next.",
                title="Loaded from Google Sheets",
            )

        def err(e):
            self.log(f"ERROR loading Google Sheet: {e}", "error")
            Messagebox.show_error(str(e), title="Google Sheets Error")

        self.run_in_thread(task, done, err)

    def _update_preview(self, df):
        """Refresh the preview treeview with the first 20 rows of df."""
        self.preview_tree.delete(*self.preview_tree.get_children())
        cols = list(df.columns)
        self.preview_tree["columns"] = cols
        for c in cols:
            self.preview_tree.heading(c, text=c)
            self.preview_tree.column(c, width=140)
        for _, row in df.head(20).iterrows():
            self.preview_tree.insert("", "end", values=[row.get(c) for c in cols])

    # -- Excel file handlers ---------------------------------------------
    def on_choose_excel(self):
        from tkinter import filedialog

        path = filedialog.askopenfilename(
            title="Choose Excel file",
            filetypes=[("Excel files", "*.xlsx *.xls *.xlsm"), ("All files", "*.*")],
        )
        if not path:
            return
        self.excel_path = path
        self.excel_key = os.path.basename(path)
        self.excel_path_var.set(path)
        try:
            sheets = core.list_sheets(path)
        except Exception as e:
            self._default_error(e)
            return
        self.sheet_combo["values"] = sheets
        if sheets:
            self.sheet_var.set(sheets[0])
        self.btn_load_excel.configure(state="normal")

    def on_load_excel_sheet(self):
        if not self.excel_path:
            return
        try:
            df = core.load_excel(self.excel_path, self.sheet_var.get())
        except Exception as e:
            self._default_error(e)
            return
        self.df = df
        self._set_chip(self.dot_excel, True)
        self.log(f"Loaded {len(df)} rows, columns: {list(df.columns)}", "success")
        self._update_preview(df)
        self.mapping = self.all_mappings.get(self.excel_key) or self.all_mappings.pop("_legacy", {}) or {}
        self._refresh_mapping_table()
        Messagebox.show_info(
            f"Loaded {len(df)} rows. Go to the 'Field Mapping' tab next "
            "(click 'Auto-Suggest Mapping' if you haven't mapped this file before).",
            title="Loaded",
        )

    # ------------------------------------------------------------------
    # Tab 3 handlers
    # ------------------------------------------------------------------
    def on_autosuggest(self):
        if self.df is None:
            Messagebox.show_warning("Load an Excel sheet first.", title="No data")
            return
        if not self.fields:
            Messagebox.show_warning("Scan the form fields first (Tab 1).", title="No fields")
            return
        self.mapping = core.suggest_mapping(list(self.df.columns), self.fields, self.learned)
        self._refresh_mapping_table()
        self.log("Auto-suggested a field mapping. Please review it before running.", "info")

    def _refresh_mapping_table(self):
        self.map_tree.delete(*self.map_tree.get_children())
        if self.df is None:
            return
        unmapped_required = []
        mapped_ids = set(self.mapping.values())
        for col in self.df.columns:
            fid = self.mapping.get(col)
            fobj = self.fields_by_id.get(fid)
            label = fobj.label if fobj else "(no match \u2014 double-click to set)"
            req = "yes" if fobj and fobj.required else ""
            tag = "missing" if not fobj else ""
            self.map_tree.insert("", "end", iid=col, values=(col, label, req), tags=(tag,) if tag else ())

        for fobj in self.fields:
            if fobj.required and fobj.element_id not in mapped_ids:
                unmapped_required.append(fobj.label)

        if unmapped_required:
            self.map_warning_var.set(
                "\u26A0  These REQUIRED form fields have no Excel column mapped: "
                + ", ".join(unmapped_required)
            )
            self._set_chip(self.dot_mapping, False)
        else:
            self.map_warning_var.set("")
            if self.mapping:
                self._set_chip(self.dot_mapping, True)

    def on_edit_mapping_row(self, _event):
        sel = self.map_tree.selection()
        if not sel:
            return
        col = sel[0]  # iid == column name

        popup = ttkb.Toplevel(title=f"Map '{col}'")
        popup.geometry("560x460")
        popup.transient(self)
        popup.grab_set()

        ttkb.Label(
            popup, text=f"Choose the form field for Excel column:", bootstyle="secondary"
        ).pack(anchor="w", padx=14, pady=(14, 0))
        ttkb.Label(popup, text=col, font=("TkDefaultFont", 12, "bold")).pack(anchor="w", padx=14, pady=(0, 10))

        tree = ttkb.Treeview(popup, columns=("field",), show="headings", height=15, bootstyle="info")
        tree.heading("field", text="Form Field")
        tree.column("field", width=520)
        tree.pack(fill="both", expand=True, padx=14)
        tree.insert("", "end", iid="none", values=("\u2014 none / unmapped \u2014",))
        for i, fobj in enumerate(self.fields):
            tree.insert("", "end", iid=f"f{i}", values=(fobj.display,))

        current_fid = self.mapping.get(col)
        if current_fid:
            for i, fobj in enumerate(self.fields):
                if fobj.element_id == current_fid:
                    tree.selection_set(f"f{i}")
                    tree.see(f"f{i}")
                    break

        def confirm(_e=None):
            sel2 = tree.selection()
            if not sel2:
                return
            iid = sel2[0]
            if iid == "none":
                self.mapping.pop(col, None)
            else:
                idx = int(iid[1:])
                self.mapping[col] = self.fields[idx].element_id
            self._refresh_mapping_table()
            popup.destroy()

        tree.bind("<Double-1>", confirm)

        btn_row = ttkb.Frame(popup, padding=14)
        btn_row.pack(fill="x")
        ttkb.Button(btn_row, text="Use Selected", command=confirm, bootstyle="success").pack(side="left")
        ttkb.Button(btn_row, text="Cancel", command=popup.destroy, bootstyle="secondary").pack(side="right")

    def on_save_mapping(self):
        if not self.excel_key:
            Messagebox.show_warning("Load an Excel sheet first.", title="No file")
            return
        self.all_mappings[self.excel_key] = self.mapping
        core.save_all_mappings(self.all_mappings)
        core.update_learned(self.learned, list(self.df.columns), self.mapping, self.fields_by_id)
        self._set_chip(self.dot_mapping, True)
        self.log(f"Mapping for '{self.excel_key}' saved (and learned for future files).", "success")
        Messagebox.show_info("Mapping saved. You can now go to the 'Run Entry' tab.", title="Saved")

    # ------------------------------------------------------------------
    # Tab 4 handlers
    # ------------------------------------------------------------------
    def on_start_run(self):
        if self.df is None or not self.mapping:
            Messagebox.show_warning("Load Excel data and save a mapping first.", title="Not ready")
            return
        if not self.driver or not self.fields:
            Messagebox.show_warning("Launch the browser and scan fields first.", title="Not ready")
            return
        self.done_indices = core.load_done_rows(self.excel_key)
        pending = [i for i in range(len(self.df)) if i not in self.done_indices]
        self.current_idx = pending[0] if pending else 0
        self.redo_count = 0
        self._update_meter()
        self._show_current_row()
        for b in (self.btn_fill, self.btn_skip):
            b.configure(state="normal")
        self.log(
            f"Ready. {len(self.df)} total rows, {len(self.done_indices)} already done, "
            f"{len(pending)} pending.",
            "info",
        )

    def on_jump_to_row(self):
        if self.df is None:
            return
        n = Querybox.get_integer(
            prompt=f"Row number (1-{len(self.df)}):", title="Jump to row",
            minvalue=1, maxvalue=len(self.df),
        )
        if n:
            self.current_idx = n - 1
            self._show_current_row()

    def _update_meter(self):
        if self.df is None or len(self.df) == 0:
            self.status_progress["value"] = 0
            self.run_meter_label_var.set("No run started")
            return
        done = len(self.done_indices)
        total = len(self.df)
        pct = int(round(100 * done / total))
        self.status_progress["value"] = pct
        self.run_meter_label_var.set(f"{done} / {total} rows done  ({pct}%)")
        if pct == 100:
            self._flash_label(self._progress_label, ["success", "primary", "success"])

    def _show_current_row(self):
        if self.df is None or self.current_idx >= len(self.df):
            self.progress_var.set("\u2705  All rows processed.")
            self.row_tree.delete(*self.row_tree.get_children())
            for b in (self.btn_fill, self.btn_redo, self.btn_submit_click, self.btn_mark_done, self.btn_skip):
                b.configure(state="disabled")
            self._update_meter()
            return
        row = self.df.iloc[self.current_idx]
        label = f"Row {self.current_idx + 1} / {len(self.df)}"
        if self.redo_count:
            label += f"   (redo #{self.redo_count})"
        self.progress_var.set(label)
        self.row_tree.delete(*self.row_tree.get_children())
        for col in self.df.columns:
            self.row_tree.insert("", "end", values=(col, row.get(col)))
        self.btn_fill.configure(state="normal")
        self.btn_skip.configure(state="normal")
        self.btn_redo.configure(state="disabled")
        self.btn_mark_done.configure(state="disabled")
        self.btn_submit_click.configure(state="disabled")
        self.btn_redo_prev.configure(state="normal" if self.current_idx > 0 else "disabled")
        self._update_meter()

    def on_fill_row(self):
        row = self.df.iloc[self.current_idx]
        self.btn_fill.configure(state="disabled")
        self.log(f"Filling row {self.current_idx + 1}...", "info")

        def task():
            return core.fill_row(self.driver, row, self.mapping, self.fields_by_id)

        def done(errors):
            if errors:
                self.log("Errors while filling this row:", "error")
                for e in errors:
                    self.log(f"   - {e}", "error")
            else:
                self.log("Row filled. Review it in the browser, solve any CAPTCHA, then submit.", "success")

            if self.auto_submit_var.get() and self.submit_id_var.get().strip():
                self.on_click_submit(auto_advance=True)
            else:
                self.btn_redo.configure(state="normal")
                self.btn_mark_done.configure(state="normal")
                self.btn_submit_click.configure(
                    state="normal" if self.submit_id_var.get().strip() else "disabled"
                )

        def err(e):
            self.btn_fill.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    def on_redo_row(self):
        self.redo_count += 1
        self.log("Redoing this row -- retyping all mapped fields...", "warn")
        self._show_current_row()
        self.progress_var.set(
            f"Row {self.current_idx + 1} / {len(self.df)}   (redo #{self.redo_count})"
        )
        self.on_fill_row()

    def on_click_submit(self, auto_advance=False):
        submit_id = self.submit_id_var.get().strip()
        if not submit_id:
            Messagebox.show_warning("Enter the submit button's element id first.", title="No submit id")
            return
        self.btn_submit_click.configure(state="disabled")

        def task():
            core.click_submit(self.driver, submit_id)

        def done(_):
            self.log("Submit button clicked.", "success")
            if auto_advance:
                self._log_and_advance("done", "auto-submitted")
            else:
                self.btn_mark_done.configure(state="normal")

        def err(e):
            self.btn_submit_click.configure(state="normal")
            self._default_error(e)

        self.run_in_thread(task, done, err)

    def on_mark_done_next(self):
        detail = "manually submitted"
        if self.redo_count:
            detail += f" (after {self.redo_count} redo(s))"
        self._log_and_advance("done", detail)

    def on_skip_row(self):
        self._log_and_advance("skipped", "user skipped")

    def _log_and_advance(self, status, detail):
        core.append_log_row(self.excel_key, self.current_idx, status, detail)
        self.log(f"Row {self.current_idx + 1}: {status} ({detail})", "success" if status == "done" else "warn")
        self.done_indices.add(self.current_idx)
        self.redo_count = 0
        self.current_idx += 1
        while self.current_idx < len(self.df) and self.current_idx in self.done_indices:
            self.current_idx += 1
        self._show_current_row()

    def on_redo_previous(self):
        prev_idx = self.current_idx - 1
        if prev_idx < 0:
            return
        answer = Messagebox.yesno(
            f"This will remove the log entry for row {prev_idx + 1} and let you "
            "re-fill/re-submit it (e.g. if the site rejected it). Continue?",
            title="Redo previous row",
        )
        if answer != "Yes":
            return
        core.remove_last_log_entry(self.excel_key, prev_idx)
        self.done_indices.discard(prev_idx)
        self.current_idx = prev_idx
        self.redo_count = 0
        self._show_current_row()


def main():
    app = DataEntryApp()
    app.mainloop()


if __name__ == "__main__":
    main()